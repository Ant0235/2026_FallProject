using UnityEditor.Build.Content;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    public static GameManager Instance;
    public int enemiesRemaining;


    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    private void Awake()
    {
        if(Instance == null)
        {
            Instance = this;
        }
        else
        {
            Destroy(gameObject);
        }
    }
    public void DecreaseEnemyCount()

    {
        enemiesRemaining --;
        Debug.Log(enemiesRemaining + " Enemies Left");
    }
    // Update is called once per frame
    void Update()
    {
       if( enemiesRemaining == 0 )
        {
            SceneManager.LoadScene("VictoryScreen");
        }

        if (Input.GetKey("r"))
        {
            SceneManager.LoadScene("Level 1");
        }
    }
}
