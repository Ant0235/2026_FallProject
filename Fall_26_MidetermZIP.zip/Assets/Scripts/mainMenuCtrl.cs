using UnityEngine;
using UnityEngine.SceneManagement;

public class mainMenuCtrl : MonoBehaviour
{
    public void OnStartClick()
    {
        SceneManager.LoadScene("Level 1");      //loads level 1 scene when clicking the start button
    }

    public void OnExitClick()
    {
#if UNITY_EDITOR                                            //Exits the play mode
        UnityEditor.EditorApplication.isPlaying = false;    //of the Unity editor
#endif
        Application.Quit();
    }
}
