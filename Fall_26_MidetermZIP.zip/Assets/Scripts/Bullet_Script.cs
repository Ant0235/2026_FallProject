using UnityEngine;

public class Bullet_Script : MonoBehaviour
{
    public Rigidbody2D Bullets;
    public float bulletSPD;
    private float despawnTime = 0f;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
      
      if (collision.gameObject.CompareTag("Buff") || collision.gameObject.CompareTag("Player"))
       {
      
         Physics2D.IgnoreCollision(collision.collider, collision.otherCollider);
        
       }

      if(collision.gameObject.CompareTag("Enemy"))
        {
            Destroy(gameObject);
        }
      
        
        
    }

    // Update is called once per frame
    void Update()
    {
        Bullets.AddForce(transform.right * bulletSPD, ForceMode2D.Impulse);
        despawnTime += Time.deltaTime;
        if(despawnTime >= 2)
        {
            Destroy(gameObject);
            Debug.Log("Timed out");
        }
    }

   
}
