using UnityEngine;

public class atkBuff_Script : MonoBehaviour
{
    public float MoveSpd;
    public Player_Script Player;

    void Start()
    {
        
    }

    private void OnCollisionEnter2D(Collision2D collision) 
    {
        if (collision.gameObject.CompareTag("Player"))
        {
            Player.BuffATK();
            Destroy(gameObject);
        }
    }

    // Update is called once per frame
    void Update()
    {
        transform.position += Vector3.left * MoveSpd * Time.deltaTime;
    }
}
