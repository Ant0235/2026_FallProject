using UnityEngine;

public class EndZone : MonoBehaviour
{
    public Player_Script Player;

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Enemy"))
        {
            Player.PlayerDamaged();
            Debug.Log("Endzone hit, " + Player.health + " health left");
        }
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
