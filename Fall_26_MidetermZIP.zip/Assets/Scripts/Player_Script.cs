using JetBrains.Annotations;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Player_Script : MonoBehaviour
{

    public float MoveSpd; //Movement speed field added to inspector
    public Rigidbody2D Player; //Rigid body reference field added to inspector
    public GameObject pewpew; //Reference field for the bullet object
    public int BulletDamage = 1;
    public int health = 5;
    [Header("UI Hearts")]
    public GameObject heart1;
    public GameObject heart2;
    public GameObject heart3;
    public GameObject heart4;
    public GameObject heart5;

    void Start()
    {
        
    }

    void Awake()
    {
        BulletDamage = 1;
    }

    public void PlayerDamaged()
    {
        health--;
        if(health<=0)
        {
            SceneManager.LoadScene("LossScreen");
        }
    }

    void Shoot() //spawn a bullet with a small right directional offset from player position
    {
        Instantiate(pewpew, Player.position + Vector2.right*1f, Quaternion.identity);
        //Debug.Log("Took a shot");
    }

     public void BuffATK()
    {
        BulletDamage = BulletDamage + 1;
        Debug.Log("Bullet dmg at" +  BulletDamage);

    }

    private void OnCollisionEnter2D(Collision2D collision) 
    {
        if (collision.gameObject.CompareTag("Enemy"))
        {
            PlayerDamaged();
            Debug.Log("Head on hit, " + health + " health left");
        }
    }


    // Update is called once per frame
    void Update()
    {
        if (Input.GetKey("up")) //move up
        {
            //Player.AddForce(transform.up * MoveSpd, ForceMode2D.Impulse);
            transform.position += Vector3.up * MoveSpd * Time.deltaTime;

        }

        if (Input.GetKey("down")) // move down
        {
            //Player.AddForce(transform.up * -1 * MoveSpd, ForceMode2D.Impulse);
            transform.position += Vector3.down * MoveSpd * Time.deltaTime;
        }

        if (Input.GetKeyDown(KeyCode.Space)) //shoot with spacebar (single press, not held)
        {
             Shoot();
        }

        
        //This whole else if chain is to turn off UI hearts when health drops
        if (health >= 5)
        {
            heart1.SetActive(true);
            heart2.SetActive(true);
            heart3.SetActive(true);
            heart4.SetActive(true);
            heart5.SetActive(true);
        }
        else if (health == 4)
        {
            heart1.SetActive(true);
            heart2.SetActive(true);
            heart3.SetActive(true);
            heart4.SetActive(true);
            heart5.SetActive(false);
        }
        else if (health == 3)
        {
            heart1.SetActive(true);
            heart2.SetActive(true);
            heart3.SetActive(true);
            heart4.SetActive(false);
            heart5.SetActive(false);
        }
        else if (health == 2)
        {
            heart1.SetActive(true);
            heart2.SetActive(true);
            heart3.SetActive(false);
            heart4.SetActive(false);
            heart5.SetActive(false);
        }
        else if (health == 1)
        {
            heart1.SetActive(true);
            heart2.SetActive(false);
            heart3.SetActive(false);
            heart4.SetActive(false);
            heart5.SetActive(false);
        }
        else if (health == 0)
        {
            heart1.SetActive(false);
            heart2.SetActive(false);
            heart3.SetActive(false);
            heart4.SetActive(false);
            heart5.SetActive(false);
        }
    }
    
}
