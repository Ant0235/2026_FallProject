using UnityEngine;

public class Spawner_script : MonoBehaviour
{
    public GameObject enemy; //Reference field added in the inspector for the enemy prefab
    
    public int spawnAmount; // Field added in inspector for the max # of spawns a particular spawner can do
    
    public float spawnInterval; //Field in inspector for the time in between spawns
    
    public int childHealth; //field for the health of the enemy spawned by a particular spawner
    
    private float Timer =0f; // variable used to calculate spawn intervals i.e line 26
    
    private int enemiesSpawned; //variable to track # of enemies already spawned

    
    void Start()
    {
        
    }

    
    void Update()
    {
        if (enemiesSpawned >= spawnAmount) //Stops the spawner from creating enemies if the amount already spawned
        {                                 // is greater than or equal to the max # of spawns
            return;
        }

        Timer += Time.deltaTime; //Adding the time thats passed to the timer variable

        if (Timer > spawnInterval) //check if enough time has passed to spawn another enemy
        {
            
           GameObject baddie = Instantiate(enemy, transform.position, Quaternion.identity);
                                                            //Creates a gameobject called baddie spawns it 
                                                            //into the scene using the enemy prefab as a blueprint
                                                            //and the spawners position (transform.position)

            Enemy_Script enemyHP = baddie.GetComponent<Enemy_Script>();
                                                            //Get the enemy script attatched to "baddie"
            
            if (enemyHP != null ) //access the setHealth function of the enemy script and pass it childHealth value
            {
                enemyHP.setHealth(childHealth);
            }

            enemiesSpawned++; //add to enemy count
            Timer = 0f;         //reset the timer
            
        }
    }

   
}

