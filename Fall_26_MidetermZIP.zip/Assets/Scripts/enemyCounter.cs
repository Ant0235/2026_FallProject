using UnityEditor.Build.Content;
using UnityEngine;

public class enemyCounter : MonoBehaviour
{
    [SerializeField] private TMPro.TextMeshProUGUI killCount;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
