using Unity.VisualScripting;
using UnityEngine;

public class Enemy_Script : MonoBehaviour
{

    public float speed;
    public GameObject ATKbuff;
    [Range(0f, 100f)] public float DropChance = 14f;
    public Player_Script Player;
    private int health;
    private int bulletDamage;

    
    void Start()
    {
        
    }

    public void setHealth(int childHealth) //set the enemy health equal to the passed childHealth value
    {
        health = childHealth;
       
    }
    void takeDamage() //Enemy takes damage, destroy the enemy if health drops to 0, and roll for buff drop 
    {
        bulletDamage = Player.BulletDamage;
        health = health - bulletDamage;
        Debug.Log("took " + bulletDamage + " damage");

        if (health <= 0)
        {
            Destroy(gameObject);
            DropRoll();
            GameManager.Instance.DecreaseEnemyCount();

        }
    }

    public void DropRoll()
    {
        float roll = Random.Range(0f, 100f);
        if (roll <= DropChance)
        {
            Instantiate(ATKbuff, transform.position, Quaternion.identity);
        }
    }

    private void OnCollisionEnter2D(Collision2D collision) //Take damage when hit with a bullet
    {
        if (collision.gameObject.CompareTag("bullet"))
        {
            takeDamage();
            
        }

        if (collision.gameObject.CompareTag("Player"))
        {
            Destroy(gameObject);
        }
    }



    // Update is called once per frame
    void Update() 
    {
        transform.position += Vector3.left * speed * Time.deltaTime; //Move the enemy left
        


    }
}
